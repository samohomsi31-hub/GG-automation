/*
 * router.js — Express router that plugs into Global Gate's existing app:
 *
 *   const ggRouter = require("./gg-research/src/router");
 *   app.use("/research", ggRouter);
 *
 * Endpoints (all under the mount path, e.g. /research):
 *   POST /jobs                       create week job {title} -> {jobId}
 *   POST /jobs/:id/upload            multipart image -> extract -> store chart (unverified)
 *   GET  /jobs/:id                   job + all charts (with image URLs)
 *   GET  /jobs/:id/image/:chartId    stored source image
 *   POST /jobs/:id/verify            save human-edited charts (+ optional title)
 *   POST /jobs/:id/render            render verified charts -> .pptx download
 *   GET  /jobs/:id/review            the verify/compose web page
 */
const express = require("express");
const multer = require("multer");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const { extractChart } = require("./extract");
const { renderWeek } = require("./render_pptx");
const { withDefaultKeepFlags, validateChart } = require("./schema");

const ROOT = path.join(__dirname, "..");
const DATA = path.join(ROOT, "data");
const UPLOADS = path.join(DATA, "uploads");
fs.mkdirSync(UPLOADS, { recursive: true });

const STYLE = JSON.parse(fs.readFileSync(path.join(ROOT, "templates", "global_gate_style.json"), "utf8"));
const TYPES = JSON.parse(fs.readFileSync(path.join(ROOT, "templates", "chart_types.json"), "utf8"));

const db = new Database(path.join(DATA, "jobs.db"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, title TEXT, created_at INTEGER);
  CREATE TABLE IF NOT EXISTS charts (id TEXT PRIMARY KEY, job_id TEXT, image_file TEXT, data_json TEXT, created_at INTEGER);
`);

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });
const router = express.Router();
router.use(express.json({ limit: "10mb" }));
const newId = (p) => p + crypto.randomBytes(4).toString("hex");

router.post("/jobs", (req, res) => {
  const id = newId("job_");
  db.prepare("INSERT INTO jobs (id,title,created_at) VALUES (?,?,?)").run(id, req.body.title || "Weekly Review", Date.now());
  res.json({ jobId: id });
});

router.post("/jobs/:id/upload", upload.single("image"), async (req, res) => {
  try {
    const job = db.prepare("SELECT * FROM jobs WHERE id=?").get(req.params.id);
    if (!job) return res.status(404).json({ error: "job not found" });
    if (!req.file) return res.status(400).json({ error: "no image uploaded" });
    const chart = await extractChart(req.file.buffer, req.file.mimetype || "image/png");
    const withFlags = withDefaultKeepFlags(chart);
    const imgFile = chart.id + path.extname(req.file.originalname || ".png");
    fs.writeFileSync(path.join(UPLOADS, imgFile), req.file.buffer);
    db.prepare("INSERT INTO charts (id,job_id,image_file,data_json,created_at) VALUES (?,?,?,?,?)")
      .run(chart.id, job.id, imgFile, JSON.stringify(withFlags), Date.now());
    res.json({ chart: withFlags, imageUrl: `/research/jobs/${job.id}/image/${chart.id}` });
  } catch (e) { res.status(500).json({ error: String(e.message || e) }); }
});

router.get("/jobs/:id", (req, res) => {
  const job = db.prepare("SELECT * FROM jobs WHERE id=?").get(req.params.id);
  if (!job) return res.status(404).json({ error: "job not found" });
  const rows = db.prepare("SELECT * FROM charts WHERE job_id=? ORDER BY created_at").all(job.id);
  res.json({ job, charts: rows.map(r => ({ ...JSON.parse(r.data_json), imageUrl: `/research/jobs/${job.id}/image/${r.id}` })) });
});

router.get("/jobs/:id/image/:chartId", (req, res) => {
  const row = db.prepare("SELECT * FROM charts WHERE id=? AND job_id=?").get(req.params.chartId, req.params.id);
  if (!row) return res.status(404).end();
  res.sendFile(path.join(UPLOADS, row.image_file));
});

router.post("/jobs/:id/verify", (req, res) => {
  const job = db.prepare("SELECT * FROM jobs WHERE id=?").get(req.params.id);
  if (!job) return res.status(404).json({ error: "job not found" });
  if (req.body.title) db.prepare("UPDATE jobs SET title=? WHERE id=?").run(req.body.title, job.id);
  const upd = db.prepare("UPDATE charts SET data_json=? WHERE id=? AND job_id=?");
  const tx = db.transaction((list) => {
    for (const c of list) {
      const errs = validateChart(c);
      if (errs.length) throw new Error(`chart ${c.id}: ${errs.join("; ")}`);
      upd.run(JSON.stringify(c), c.id, job.id);
    }
  });
  try { tx(req.body.charts || []); res.json({ status: "saved" }); }
  catch (e) { res.status(400).json({ error: String(e.message || e) }); }
});

router.post("/jobs/:id/render", async (req, res) => {
  const job = db.prepare("SELECT * FROM jobs WHERE id=?").get(req.params.id);
  if (!job) return res.status(404).json({ error: "job not found" });
  if (req.body.title) db.prepare("UPDATE jobs SET title=? WHERE id=?").run(req.body.title, job.id);
  const title = (db.prepare("SELECT title FROM jobs WHERE id=?").get(job.id) || {}).title;
  const rows = db.prepare("SELECT * FROM charts WHERE job_id=? ORDER BY created_at").all(job.id);
  const charts = rows.map(r => JSON.parse(r.data_json));
  if (!charts.length) return res.status(400).json({ error: "no charts" });
  if (charts.length > 4) return res.status(400).json({ error: "max 4 charts per slide (auto-layout supports 1-4)" });
  const out = path.join(DATA, `${job.id}.pptx`);
  try { await renderWeek({ title, charts }, STYLE, TYPES, out); res.download(out, "weekly_review.pptx"); }
  catch (e) { res.status(400).json({ error: String(e.message || e) }); }
});

router.get("/jobs/:id/review", (req, res) => res.sendFile(path.join(ROOT, "public", "review.html")));

module.exports = router;
