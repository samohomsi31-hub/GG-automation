/*
 * extract.js — Stage 1: read a chart image into structured data via Claude vision.
 * Keeps EVERYTHING (all columns/rows); the human trims at verify time.
 * Requires: @anthropic-ai/sdk  and  ANTHROPIC_API_KEY.
 */
const Anthropic = require("@anthropic-ai/sdk");

const SYSTEM = `You are a precise data-extraction engine for financial research charts.
Return ONLY valid JSON (no prose, no markdown fences).

CRITICAL RULES:
- Extract EVERYTHING visible: every column (year/period) and every data row, including summary
  rows like "Change $", "Change %", "Sponsor as % of M&A". A human decides later what to drop.
- Read only what is printed. If a value is not printed or you cannot read it confidently, use null.
  NEVER guess a digit. A wrong-but-plausible number is worse than null.
- Preserve left-to-right column order exactly.
- Classify the chart as one of: "stacked_bar_plus_line", "clustered_bar", "multi_line", "line_plus_trend".
- Give each series a "role": "stacked", "bar", "line", or "trend".

Output JSON:
{
  "chartType": "<id>",
  "header": "<the chart's title/header text>",
  "unit": "<e.g. $bn, $B, count, years, or empty>",
  "categories": ["...","..."],
  "series": [ {"key":"<snake_case>","label":"<as printed>","role":"<stacked|bar|line|trend>","values":[num_or_null,...]} ],
  "notes": "<uncertainties, overlapping labels, approximate curve reads>"
}`;

async function extractChart(imageBuffer, mediaType = "image/png") {
  const client = new Anthropic(); // reads ANTHROPIC_API_KEY
  const msg = await client.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 4000,
    system: SYSTEM,
    messages: [{
      role: "user",
      content: [
        { type: "image", source: { type: "base64", media_type: mediaType, data: imageBuffer.toString("base64") } },
        { type: "text", text: "Extract this chart as JSON now." },
      ],
    }],
  });
  let text = msg.content.filter(b => b.type === "text").map(b => b.text).join("").trim();
  if (text.startsWith("```")) text = text.replace(/^```[a-z]*\n?/, "").replace(/```$/, "").trim();
  const parsed = JSON.parse(text);
  parsed.id = "chart_" + Math.random().toString(36).slice(2, 8);
  for (const s of parsed.series) s.confidence = "unverified";
  return parsed;
}

module.exports = { extractChart };
