/*
 * render_pptx.js — Stage 4: render verified, trimmed charts onto one Global Gate slide.
 * House style: navy header bar over every chart, data value labels shown, tan/navy palette,
 * serif title (the weekly action-title typed by the analyst), logo bottom-right.
 *
 * CLI: node render_pptx.js <week.json> <style.json> <chart_types.json> <out.pptx>
 * Lib: const { renderWeek } = require("./render_pptx")
 *
 * week.json = { title: "<action title>", charts: [ <trimmed verified chart>, ... ] }   (1..4 charts)
 */
const pptxgen = require("pptxgenjs");
const fs = require("fs");
const { trimChart, chartVerified } = require("./schema");

const byRole = (c, role) => c.series.filter(s => (s.role || "") === role);

function niceMaxStacked(stacked, n) {
  let mx = 0;
  for (let i = 0; i < n; i++) { let t = 0; for (const s of stacked) t += (s.values[i] || 0); mx = Math.max(mx, t); }
  return roundUpNice(mx);
}
function niceMax(vals) { return roundUpNice(Math.max(...vals.flat().map(v => v || 0))); }
function roundUpNice(m) {
  if (m <= 0) return 10;
  const pow = Math.pow(10, Math.floor(Math.log10(m)));
  return Math.ceil(m / pow) * pow;
}

// number format for value labels, based on unit
function labelFmt(unit) {
  const u = (unit || "").toLowerCase();
  if (u.includes("$b") || u === "$bn" || u.includes("billion")) return '"$"#,##0"B"';
  if (u.includes("$")) return '"$"#,##0';
  return "#,##0";
}

// navy header bar with white centered text — the universal Global Gate chart wrapper
function headerBar(slide, text, style, pos) {
  slide.addShape("rect", { x: pos.x, y: pos.y - 0.42, w: pos.w, h: 0.34,
    fill: { color: style.palette.navy_header_bg }, line: { type: "none" } });
  slide.addText(text || "", { x: pos.x, y: pos.y - 0.42, w: pos.w, h: 0.34, align: "center",
    valign: "middle", color: "FFFFFF", bold: true, margin: 0,
    fontSize: style.sizes.panel_header_pt, fontFace: style.fonts.panel_header });
}

function colorFor(style, key, idx) {
  const fb = ["1F3864", "8FAADC", "C9A227", "A8C0D8", "E8A87C", "7B4F9E"];
  return style.palette.series[key] || fb[idx % fb.length];
}

function drawStackedBarPlusLine(slide, pres, chart, style, pos, dense) {
  const cats = chart.categories, stacked = byRole(chart, "stacked"), lines = byRole(chart, "line");
  const barData = stacked.map(s => ({ name: s.label, labels: cats, values: s.values.map(v => v ?? 0) }));
  const barColors = stacked.map((s, i) => colorFor(style, s.key, i));
  const defs = [{ type: pres.charts.BAR, data: barData, options: { barGrouping: "stacked", chartColors: barColors,
    showValue: true, dataLabelFontSize: style.sizes.data_label_pt, dataLabelColor: "FFFFFF",
    dataLabelFormatCode: labelFmt(chart.unit) } }];
  const valAxes = [{ valAxisMinVal: 0, valAxisMaxVal: niceMaxStacked(stacked, cats.length),
    valGridLine: { color: "E2E8F0", size: 0.5 }, valAxisLabelFormatCode: labelFmt(chart.unit) }];
  const catAxes = [{ catAxisLabelFontSize: style.sizes.axis_pt }];
  if (lines.length) {
    defs.push({ type: pres.charts.LINE, data: lines.map(s => ({ name: s.label, labels: cats, values: s.values.map(v => v ?? 0) })),
      options: { chartColors: [style.palette.line_neutral], lineSize: 2, lineDataSymbol: "circle",
        lineDataSymbolSize: 5, secondaryValAxis: true, secondaryCatAxis: true } });
    valAxes.push({ valAxisMinVal: 0, valAxisMaxVal: niceMax(lines.map(s => s.values)),
      valGridLine: { style: "none" }, valAxisLabelFormatCode: "#,##0" });
    catAxes.push({ catAxisHidden: true });
  }
  const chH = dense ? pos.h + 0.3 : pos.h;
  slide.addChart(defs, { x: pos.x, y: pos.y, w: pos.w, h: chH, barDir: "col", showLegend: true,
    legendPos: "b", legendFontSize: dense ? 6 : style.sizes.legend_pt,
    catAxisLabelFontSize: style.sizes.axis_pt, valAxisLabelFontSize: style.sizes.axis_pt, valAxes, catAxes });
}

function drawClusteredBar(slide, pres, chart, style, pos, dense) {
  const cats = chart.categories, bars = byRole(chart, "bar");
  const data = bars.map(s => ({ name: s.label, labels: cats, values: s.values.map(v => v ?? 0) }));
  slide.addChart(pres.charts.BAR, data, { x: pos.x, y: pos.y, w: pos.w, h: pos.h, barDir: "col",
    chartColors: bars.map((s, i) => colorFor(style, s.key, i)),
    showValue: true, dataLabelFontSize: style.sizes.data_label_pt, dataLabelPosition: "outEnd",
    dataLabelColor: style.palette.text_dark, dataLabelFormatCode: labelFmt(chart.unit),
    showLegend: bars.length > 1, legendPos: "b", legendFontSize: style.sizes.legend_pt,
    catAxisLabelFontSize: style.sizes.axis_pt, valAxisLabelFontSize: style.sizes.axis_pt,
    valAxisLabelFormatCode: labelFmt(chart.unit), valGridLine: { color: "E2E8F0", size: 0.5 } });
}

function drawMultiLine(slide, pres, chart, style, pos) {
  const cats = chart.categories, lines = byRole(chart, "line");
  slide.addChart(pres.charts.LINE, lines.map(s => ({ name: s.label, labels: cats, values: s.values.map(v => v ?? 0) })),
    { x: pos.x, y: pos.y, w: pos.w, h: pos.h, chartColors: lines.map((s, i) => colorFor(style, s.key, i)),
      lineSize: 2, lineSmooth: true, showLegend: true, legendPos: "b", legendFontSize: style.sizes.legend_pt,
      catAxisLabelFontSize: style.sizes.axis_pt, valAxisLabelFontSize: style.sizes.axis_pt, valAxisLabelFormatCode: "#,##0" });
}

function drawLinePlusTrend(slide, pres, chart, style, pos) {
  const cats = chart.categories, main = byRole(chart, "line"), trend = byRole(chart, "trend");
  const data = [...main, ...trend].map(s => ({ name: s.label, labels: cats, values: s.values.map(v => v ?? 0) }));
  const colors = [colorFor(style, (main[0] || {}).key, 0), style.palette.trend_dashed].slice(0, data.length);
  slide.addChart(pres.charts.LINE, data, { x: pos.x, y: pos.y, w: pos.w, h: pos.h, chartColors: colors,
    lineSize: 2, lineSmooth: true, showLegend: true, legendPos: "b", legendFontSize: style.sizes.legend_pt,
    catAxisLabelFontSize: style.sizes.axis_pt, valAxisLabelFontSize: style.sizes.axis_pt });
}

const DRAW = {
  stacked_bar_plus_line: drawStackedBarPlusLine,
  clustered_bar: drawClusteredBar,
  multi_line: drawMultiLine,
  line_plus_trend: drawLinePlusTrend,
};

function renderWeek(week, style, types, outPath) {
  const bad = week.charts.filter(c => !chartVerified(c)).map(c => c.id);
  if (bad.length) throw new Error("Refusing to render unverified charts: " + bad.join(", "));
  const charts = week.charts.map(trimChart);
  const slots = types.auto_layout[String(charts.length)];
  if (!slots) throw new Error(`No auto-layout for ${charts.length} charts (supported 1-4).`);

  const pres = new pptxgen();
  pres.layout = "LAYOUT_WIDE";
  pres.title = week.title || "Global Gate Weekly Review";
  const slide = pres.addSlide();
  slide.background = { color: style.palette.slide_bg };

  // weekly action-title (typed by analyst), serif, top-left, navy
  slide.addText(week.title || "", { x: 0.4, y: 0.22, w: 12.5, h: 0.6,
    fontSize: style.sizes.slide_title_pt, color: style.palette.text_dark, fontFace: style.fonts.title });

  const dense = charts.length >= 3;
  charts.forEach((chart, i) => {
    const pos = slots[i];
    headerBar(slide, chart.header, style, pos);
    const fn = DRAW[chart.chartType];
    if (!fn) { console.error(`(skip) unknown chartType ${chart.chartType}`); return; }
    fn(slide, pres, chart, style, pos, dense);
  });

  // source line bottom-left if any chart carries one
  const src = charts.map(c => c.source).filter(Boolean)[0];
  if (src) slide.addText("Source: " + src, { x: 0.4, y: 6.95, w: 9, h: 0.3,
    fontSize: style.sizes.source_pt, color: style.palette.text_muted, fontFace: style.fonts.body });

  // logo placeholder bottom-right (swap for real PNG/SVG when supplied)
  slide.addText(style.logo_text, { x: 11.0, y: 6.9, w: 2.0, h: 0.35, align: "right",
    fontSize: 14, italic: true, color: style.palette.navy, fontFace: style.fonts.title });

  return pres.writeFile({ fileName: outPath }).then(() => outPath);
}

module.exports = { renderWeek };

if (require.main === module) {
  const [,, weekPath, stylePath, typesPath, outPath] = process.argv;
  if (!weekPath || !stylePath || !typesPath || !outPath) {
    console.error("usage: node render_pptx.js <week.json> <style.json> <chart_types.json> <out.pptx>");
    process.exit(1);
  }
  const week = JSON.parse(fs.readFileSync(weekPath, "utf8"));
  const style = JSON.parse(fs.readFileSync(stylePath, "utf8"));
  const types = JSON.parse(fs.readFileSync(typesPath, "utf8"));
  renderWeek(week, style, types, outPath).then(p => console.log("WROTE " + p))
    .catch(e => { console.error(e.message); process.exit(3); });
}
