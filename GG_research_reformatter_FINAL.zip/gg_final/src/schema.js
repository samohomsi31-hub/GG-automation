/* schema.js — data contract + column/row trimming (CommonJS). */

function validateChart(c) {
  const errs = [];
  if (!c.chartType) errs.push("missing chartType");
  if (!Array.isArray(c.categories) || !c.categories.length) errs.push("no categories");
  if (!Array.isArray(c.series) || !c.series.length) errs.push("no series");
  for (const s of c.series || [])
    if (s.values && s.values.length !== c.categories.length)
      errs.push(`series "${s.key}" has ${s.values.length} values but ${c.categories.length} categories`);
  return errs;
}

function withDefaultKeepFlags(c) {
  return {
    ...c,
    keepCategories: c.keepCategories || c.categories.map(() => true),
    keepSeries: c.keepSeries || c.series.map(() => true),
  };
}

function trimChart(c) {
  const keepCat = c.keepCategories || c.categories.map(() => true);
  const keepSer = c.keepSeries || c.series.map(() => true);
  const categories = c.categories.filter((_, i) => keepCat[i]);
  const series = c.series
    .filter((_, i) => keepSer[i])
    .map(s => ({ ...s, values: s.values.filter((_, i) => keepCat[i]) }));
  return { ...c, categories, series, keepCategories: undefined, keepSeries: undefined };
}

function chartVerified(c) {
  return c.series.every(s => s.confidence === "verified" || s.confidence === "corrected");
}

module.exports = { validateChart, withDefaultKeepFlags, trimChart, chartVerified };
