/* server.js — standalone launcher for local testing. In production, mount src/router.js
   into the existing Express app instead of running this. */
const express = require("express");
const ggRouter = require("./src/router");
const app = express();
app.use("/research", ggRouter);
app.get("/", (_req, res) => res.redirect("/research/jobs/new/review"));
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`GG research tool: http://localhost:${PORT}/research/jobs/new/review`));
