# Global Gate — Research Reformatter

Automates the weekly task of turning external research charts (Evercore, Bernstein, Crunchbase/PitchBook, etc.)
into a Global Gate house-style **editable** PowerPoint slide.

```
Upload external charts  →  AI reads the data  →  You verify numbers + pick columns/rows  →  Editable GG slide
```

## Quick start (local test)

```bash
npm install
export ANTHROPIC_API_KEY=sk-...        # Windows: set ANTHROPIC_API_KEY=sk-...
npm start
# open the printed URL, type a title, upload chart images, verify, download .pptx
```

Render the bundled example without the API (no key needed):

```bash
npm run render:example     # writes out_example.pptx
```

## Integrate into the existing Express API (3 lines)

```js
const ggRouter = require("./gg-research/src/router");
app.use("/research", ggRouter);
```

Then `npm install` in the app and set `ANTHROPIC_API_KEY` in Azure App Service configuration.
Users open `/research/jobs/<id>/review`.

## How it works

| Stage | File | What it does |
|---|---|---|
| Extract | `src/extract.js` | Claude vision reads a chart image into JSON; keeps every column/row; returns `null` for anything it can't read confidently (never guesses) |
| Verify | `public/review.html` | Shows numbers next to the source image; you fix flagged cells, untick columns/rows to drop (e.g. 2021-22, summary rows), type the week's action-title |
| Render | `src/render_pptx.js` | Builds the editable .pptx in Global Gate house style; refuses to render unverified data |
| API | `src/router.js` | Express router + SQLite job storage (`better-sqlite3`) |

## House style (from the GGC brand guide)

- Navy `#1F3864` header bar with white centered text above every chart
- Data value labels shown on bars/points (e.g. `$242B`)
- Tan `#E8A87C` accent, muted blues for lines, serif action-title top-left, logo bottom-right
- Auto-arranges 1–4 charts per slide

## Known placeholders to replace before production

1. **Logo** — currently a text "GlobalGate" bottom-right. Replace with the real PNG (transparent) / SVG
   in `render_pptx.js` (`addImage` instead of the logo `addText`).
2. **Exact brand hex values** — tan/cream/orange in `templates/global_gate_style.json` were eyeballed
   from the brand-guide PDF. Swap for the official spec (one file, no code change).
3. **Accuracy** — run a few real weeks through it and compare against manually-built slides before
   relying on it for client deliverables. The verify step is what guarantees correctness.

## Supported chart types

`stacked_bar_plus_line`, `clustered_bar`, `multi_line`, `line_plus_trend` — covers the Evercore,
Bernstein, and Crunchbase/PitchBook formats in the brand guide. A new visual = one entry in
`templates/chart_types.json` + one `draw<Type>()` in `render_pptx.js`.
